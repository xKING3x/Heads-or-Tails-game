import random
import time

start_money = 50
print('Welcome to heads or tails game!')
print('If you choose to play your starter account balance will be:', start_money, 'euros')
start_answer = input('Are you ready to play? (yes/no): ').lower()

def menu():
    global start_money
    while start_money > 0:
        if start_answer == 'yes':
            bet_answer = int(input('How much money do you want to bet? ( >0 ): '))
            if bet_answer <= 0:
                print("Your bet needs to be > 0!...Please try again")
                continue
            elif bet_answer > start_money:
                print("You don't have enough money!...Try again")
                continue
            elif bet_answer == start_money:
                print("You can bet that amount of money but you will not have anymore money if you lose it!")
            else:
                print("Ok, good luck!")
        elif start_answer == 'no':
            print('Ok, goodbye')
            exit()
        else:
            print('Invalid answer')
            exit()

        def game():
            global start_money
            players_choice = input('Pick... Heads or Tails?: ').lower()
            
            if players_choice not in ['heads', 'tails']:
                print('Invalid answer...Try again!')
                return

            result = random.choice(['heads', 'tails'])
            time.sleep(2)
            print('The coin side is...', result)

            if result == players_choice:
                print('You won here is your money, +', bet_answer, 'euros')
                start_money += bet_answer
                time.sleep(2)
                print('Your remaining amount of money is,', start_money)
            else:
                print('You lost...You are -', bet_answer, 'euros')
                start_money -= bet_answer
                time.sleep(2)
                print('Your remaining amount of money is,', start_money)

                if start_money <= 0:
                    print('You lost all your money...Thanks for playing!')
                    exit()

        game()

menu()
